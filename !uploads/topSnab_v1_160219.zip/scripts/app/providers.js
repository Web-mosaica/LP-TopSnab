//'use strict';

/* Controllers */

//var beringProviders = angular.module('beringProviders',[])
